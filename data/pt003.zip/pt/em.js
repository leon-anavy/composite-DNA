function email(sub) {
document.write('<a href=\"mailto:mtr@mechon-mamre.org?subject=' + sub + '\">Write Us!</a>');
}
